-- Calculate the average salary for each department
SELECT department, AVG(salary) AS avg_salary
FROM employees
GROUP BY department;

-- Bonus: Calculate the highest salary for each department and retrieve the department name, highest salary, and the employee(s) with that salary
WITH highest_salaries AS (
    SELECT department, MAX(salary) AS max_salary
    FROM employees
    GROUP BY department
)
SELECT e.department, e.name, e.salary
FROM employees e
JOIN highest_salaries hs ON e.department = hs.department AND e.salary = hs.max_salary;
