-- Delete a specific customer by their customer_id
DELETE FROM customers
WHERE customer_id = 1;

-- Bonus: Modify the query to delete any related records associated with the customer being deleted to maintain data integrity
-- This assumes ON DELETE CASCADE is set on foreign keys
DELETE FROM orders WHERE customer_id = 1;
DELETE FROM sales WHERE customer_id = 1;
DELETE FROM customers WHERE customer_id = 1;
