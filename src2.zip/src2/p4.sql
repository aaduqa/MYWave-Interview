-- Update the price of a specific product by specifying the product_id
UPDATE inventories
SET price = 30.00
WHERE product_id = 1;

-- Bonus: Modify the query to update the price of all products by increasing it by 10%
UPDATE inventories
SET price = price * 1.10;
