-- Retrieve customer names, order dates, and total amounts for all orders placed by customers from the city 'New York'
SELECT c.customer_name, o.order_date, o.total_amount
FROM orders o
JOIN customers c ON o.customer_id = c.customer_id
WHERE c.city = 'New York';

-- Bonus: Modify the query to include the average total amount per customer for orders placed in the city 'New York'
SELECT c.customer_name, o.order_date, o.total_amount,
       AVG(o.total_amount) OVER (PARTITION BY c.customer_id) AS avg_total_amount
FROM orders o
JOIN customers c ON o.customer_id = c.customer_id
WHERE c.city = 'New York';
