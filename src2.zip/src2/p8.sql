-- Suggested index to improve performance of the given query
CREATE INDEX idx_department_salary ON employees(department, salary);

-- Explanation:
-- The index on (department, salary) will help the query filter efficiently
-- by department first and then by salary within the filtered department.

-- Bonus: Discussion of trade-offs
-- The index will consume additional storage and can slow down write operations
-- like INSERT, UPDATE, and DELETE, as the index needs to be maintained.
