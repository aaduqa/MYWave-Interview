-- Problem 1: Table Creation (DDL)

-- Create the employees table
CREATE TABLE employees (
    id SERIAL PRIMARY KEY,
    name TEXT NOT NULL,
    position TEXT,
    department TEXT,
    salary NUMERIC
);

-- Create the customers table
CREATE TABLE customers (
    customer_id SERIAL PRIMARY KEY,
    customer_name TEXT NOT NULL,
    city TEXT
);

-- Create the inventories table
CREATE TABLE inventories (
    product_id SERIAL PRIMARY KEY,
    product_name TEXT,
    quantity INTEGER,
    price NUMERIC
);

-- Create the orders table
CREATE TABLE orders (
    order_id SERIAL PRIMARY KEY,
    order_date DATE,
    customer_id INTEGER REFERENCES customers(customer_id),
    total_amount NUMERIC
);

-- Create the sales table
CREATE TABLE sales (
    order_id SERIAL PRIMARY KEY,  -- Auto-incrementing order_id
    customer_id INTEGER REFERENCES customers(customer_id),
    product_id INTEGER REFERENCES inventories(product_id),
    quantity INTEGER,
    sale_date DATE
);

-- Insert dummy data into employees table
INSERT INTO employees (name, position, department, salary) VALUES
('Ahmad', 'Manager', 'Sales', 75000),
('Ali', 'Developer', 'IT', 90000),
('Siti', 'Clerk', 'HR', 45000);

-- Insert dummy data into customers table
INSERT INTO customers (customer_name, city) VALUES
('John', 'New York'),
('Bob', 'Los Angeles'),
('Awang', 'New York');

-- Insert dummy data into inventories table
INSERT INTO inventories (product_name, quantity, price) VALUES
('Product A', 100, 25.5),
('Product B', 200, 15.75);

-- Insert dummy data into orders table
INSERT INTO orders (order_date, customer_id, total_amount) VALUES
('2023-01-15', 1, 102.5),
('2023-01-20', 2, 50.0);

-- Insert dummy data into sales table
INSERT INTO sales (customer_id, product_id, quantity, sale_date) VALUES
(1, 1, 2, '2023-01-15'),
(2, 2, 3, '2023-01-20');
