let taskId = 0;
const taskForm = document.getElementById('taskForm');
const taskList = document.getElementById('taskList');

taskForm.addEventListener('submit', function (e) {
    e.preventDefault();
    const title = document.getElementById('taskTitle').value;
    const description = document.getElementById('taskDescription').value;
    const priority = document.getElementById('taskPriority').value;

    addTask(title, description, priority);
    taskForm.reset(); // Clear form after adding task
});

function addTask(title, description, priority) {
    taskId++;
    const task = document.createElement('li');
    task.classList.add('task');
    task.setAttribute('data-id', taskId);
    
    let priorityClass = '';
    if (priority === 'high') {
        priorityClass = 'priority-high';
    } else if (priority === 'medium') {
        priorityClass = 'priority-medium';
    } else {
        priorityClass = 'priority-low';
    }

    task.innerHTML = `
        <div>
            <h3 class="${priorityClass}">${title}</h3>
            <p>${description}</p>
            <p>Priority: ${priority}</p>
        </div>
        <div class="task-buttons">
            <button class="complete" onclick="toggleComplete(${taskId})">Complete</button>
            <button class="edit" onclick="editTask(${taskId})">Edit</button>
            <button class="delete" onclick="deleteTask(${taskId})">Delete</button>
        </div>
    `;
    taskList.appendChild(task);
}

function toggleComplete(id) {
    const task = document.querySelector(`li[data-id='${id}']`);
    task.classList.toggle('completed');
}

function deleteTask(id) {
    const task = document.querySelector(`li[data-id='${id}']`);
    taskList.removeChild(task);
}

function editTask(id) {
    const task = document.querySelector(`li[data-id='${id}']`);
    const title = task.querySelector('h3').innerText;
    const description = task.querySelector('p').innerText;
    const priority = task.querySelector('p:nth-child(3)').innerText.split(": ")[1];

    document.getElementById('taskTitle').value = title;
    document.getElementById('taskDescription').value = description;
    document.getElementById('taskPriority').value = priority;

    deleteTask(id); // Remove task and allow for new entry
}
