import java.util.ArrayList;

public class p5 {

    public static ArrayList<Integer> symmetricDifference(int[] list1, int[] list2) {
        ArrayList<Integer> result = new ArrayList<>();
        // Check for elements in list1 that are not in list2
        for (int elem1 : list1) {
            boolean found = false;
            for (int elem2 : list2) {
                if (elem1 == elem2) {
                    found = true;
                    break;
                }
            }
            if (!found && !result.contains(elem1)) {
                result.add(elem1); // Add to result if it’s unique to list1
            }
        }
        // Check for elements in list2 that are not in list1
        for (int elem2 : list2) {
            boolean found = false;
            for (int elem1 : list1) {
                if (elem2 == elem1) {
                    found = true;
                    break;
                }
            }
            if (!found && !result.contains(elem2)) {
                result.add(elem2); // Add to result if it’s unique to list2
            }
        }
        return result; // Return the list of symmetric difference elements
    }

    public static void main(String[] args) {
        int[] list1 = {4, 5, 2, 3, 1, 6};
        int[] list2 = {8, 7, 6, 9, 4, 5};
        ArrayList<Integer> symDiff = symmetricDifference(list1, list2);
        for (int num : symDiff) {
            System.out.print(num + " ");
        }
    }
}
