import java.util.HashMap;

public class p3 {

    // Using recursion to prevent recalculate same number multiple times.
    public static int fibonacci(int n, HashMap<Integer, Integer> memo) {
        // Check if the result is already computed and stored in memo
        if (memo.containsKey(n)) {
            return memo.get(n);
        }
        // Base cases: return n for Fibonacci(0) and Fibonacci(1)
        if (n <= 1) {
            return n;
        }
        // Recursively compute Fibonacci with memoization
        int fib = fibonacci(n - 1, memo) + fibonacci(n - 2, memo);
        memo.put(n, fib); // Store the result in memo
        return fib;
    }

    public static void generateFibonacciSequence(int numElements) {
        HashMap<Integer, Integer> memo = new HashMap<>(); // Memoization cache
        // Generate and print Fibonacci sequence up to numElements
        for (int i = 0; i < numElements; i++) {
            System.out.print(fibonacci(i, memo) + " ");
        }
    }

    public static void main(String[] args) {
        generateFibonacciSequence(10);
    }
}
