public class p7 {

    // Function to calculate the square root of a non-negative integer x using binary search.
    public static int squareRoot(int x) {
        if (x == 0 || x == 1) {
            return x; // Base cases: the square root of 0 is 0, and the square root of 1 is 1
        }

        int start = 1, end = x, result = 0;
        while (start <= end) {
            int mid = (start + end) / 2;

            // If mid*mid equals x, we've found the square root
            if (mid * mid == x) {
                return mid;
            }

            // If mid*mid is less than x, the square root must be greater
            if (mid * mid < x) {
                start = mid + 1;
                result = mid; // Update result since mid might be the floor value of the square root
            } else {
                end = mid - 1; // If mid*mid is greater than x, reduce the range
            }
        }

        return result;
    }

    public static void main(String[] args) {
        System.out.println("Square root of 4 is: " + squareRoot(4));
        System.out.println("Square root of 9 is: " + squareRoot(9));
        System.out.println("Square root of 16 is: " + squareRoot(16));
        System.out.println("Square root of 25 is: " + squareRoot(25));
        System.out.println("Square root of 36 is: " + squareRoot(36));
    }
}
