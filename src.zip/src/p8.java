import java.util.HashMap;

public class p8 {

    public static boolean areAnagrams(String s1, String s2) {
        // normalize both strings by removing non-alphanumeric characters and converting to lowercase
        String normalizedS1 = normalizeString(s1);
        String normalizedS2 = normalizeString(s2);

        // if the lengths of the are different, they cannot be anagrams
        if (normalizedS1.length() != normalizedS2.length()) {
            return false;
        }

        // use a HashMap to count occurrences of each character in the first string
        HashMap<Character, Integer> charCountMap = new HashMap<>();
        for (char ch : normalizedS1.toCharArray()) {
            charCountMap.put(ch, charCountMap.getOrDefault(ch, 0) + 1);
        }

        // check if the second string has the same character counts
        for (char ch : normalizedS2.toCharArray()) {
            if (!charCountMap.containsKey(ch) || charCountMap.get(ch) == 0) {
                return false;
            }
            charCountMap.put(ch, charCountMap.get(ch) - 1);
        }

        return true; // If all checks pass, the strings are anagrams
    }

    // Helper function to normalize a string: remove non-alphanumeric characters and convert to lowercase
    private static String normalizeString(String str) {
        StringBuilder sb = new StringBuilder();
        for (char ch : str.toCharArray()) {
            if (Character.isLetterOrDigit(ch)) {
                sb.append(Character.toLowerCase(ch));
            }
        }
        return sb.toString();
    }

    public static void main(String[] args) {
        System.out.println(areAnagrams("listen", "silent")); // Expected output: true
        System.out.println(areAnagrams("debit card", "Bad credit")); // Expected output: true
        System.out.println(areAnagrams("hello", "bye")); // Expected output: false
        System.out.println(areAnagrams("restful", "fluster")); // Expected output: true
        System.out.println(areAnagrams("listen", "silentt")); // Expected output: false
        System.out.println(areAnagrams("Conversation", "Voices, rant on")); // Expected output: true
    }
}
