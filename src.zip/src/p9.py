from collections import deque

def shortest_path(graph, start, end):
    # If start and end are the same
    if start == end:
        return True, [start]
    
    # BFS initialization
    queue = deque([(start, [start])])
    visited = set()
    
    while queue:
        node, path = queue.popleft()
        
        # Mark the node as visited
        if node not in visited:
            visited.add(node)
            
            # Explore neighbors
            for neighbor in graph.get(node, []):
                if neighbor == end:
                    return True, path + [neighbor]
                queue.append((neighbor, path + [neighbor]))
    
    # No path found
    return False, []

# Example usage
graph = {
    'A': ['B'],
    'B': ['A', 'C', 'D'],
    'C': ['F'],
    'D': ['E'],
    'E': ['F', 'G'],
    'F': ['B'],
    'G': [],
    'H': []
}

# Test cases
print(shortest_path(graph, 'D', 'B'))  
print(shortest_path(graph, 'F', 'A'))  
print(shortest_path(graph, 'G', 'C'))  
print(shortest_path(graph, 'E', 'D'))  
