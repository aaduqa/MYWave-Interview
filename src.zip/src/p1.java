public class p1 {
    
    // Implementing Bubble Sort
    // Bubble Sort repeatedly steps through the list, compares adjacent elements, and swaps them if they are in the wrong order
    public static int[] bubbleSort(int[] arr) {
        int n = arr.length; // Length of the array
        // Traverse through all array elements
        for (int i = 0; i < n - 1; i++) {
            // Last i elements are already sorted, so we can skip them
            for (int j = 0; j < n - i - 1; j++) {
                // Swap if the element found is greater than the next element
                if (arr[j] > arr[j + 1]) {
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }
        return arr;
    }

    public static void main(String[] args) {
        int[] inputArray = {21, 400, 8, -3, 77, 99, -16, 55, 111, -36, 28};
        int[] sortedArray = bubbleSort(inputArray);
        // Printing the sorted array
        for (int num : sortedArray) {
            System.out.print(num + " ");
        }
    }
}
