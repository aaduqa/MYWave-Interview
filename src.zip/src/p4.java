import java.util.ArrayList;

public class p4 {

    public static ArrayList<Integer> listIntersection(int[] list1, int[] list2) {
        ArrayList<Integer> result = new ArrayList<>();
        // Iterate through each element in list1
        for (int elem1 : list1) {
            // Check if elem1 exists in list2 and is not already in the result list
            for (int elem2 : list2) {
                if (elem1 == elem2 && !result.contains(elem1)) {
                    result.add(elem1); // Add to result if it's an intersection
                }
            }
        }
        return result; // Return the list of intersecting elements
    }

    public static void main(String[] args) {
        int[] list1 = {4, 5, 2, 3, 1, 6};
        int[] list2 = {8, 7, 6, 9, 4, 5};
        ArrayList<Integer> intersection = listIntersection(list1, list2);
        // Printing the intersection
        for (int num : intersection) {
            System.out.print(num + " ");
        }
        // Expected output: 4 5 6
    }
}

