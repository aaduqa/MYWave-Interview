import java.util.HashMap;

public class p6 {

    public static void findMaxOccurrence(String input) {
        HashMap<Character, Integer> charCountMap = new HashMap<>();
        char maxChar = ' ';
        int maxCount = 0;

        // Iterate through each character in the input string
        for (char ch : input.toCharArray()) {
            // Consider only alphabetic characters and digits (ignoring spaces and punctuation)
            if (Character.isLetterOrDigit(ch)) {
                // Increment the character count in the map
                charCountMap.put(ch, charCountMap.getOrDefault(ch, 0) + 1);

                // Update maxChar and maxCount if this character's count is greater than the current max
                if (charCountMap.get(ch) > maxCount) {
                    maxChar = ch;
                    maxCount = charCountMap.get(ch);
                }
            }
        }

        // Output the character with the maximum occurrence and its count
        System.out.println("Character: '" + maxChar + "', Occurrence: " + maxCount);
    }

    public static void main(String[] args) {
        findMaxOccurrence("Hello, world!");
    }
}
